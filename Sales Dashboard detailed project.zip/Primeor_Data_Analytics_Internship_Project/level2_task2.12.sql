USE ecommerce;

SELECT Product_Name, SUM(Profit) AS Total_Profit
FROM sales_data
GROUP BY Product_Name
ORDER BY Total_Profit DESC
LIMIT 10;

SELECT Customer_Name, SUM(Sales) AS Total_Sales
FROM sales_data
GROUP BY Customer_Name
ORDER BY Total_Sales DESC
LIMIT 10;
SELECT Region, SUM(Sales) AS Total_Sales
FROM sales_data
GROUP BY Region
ORDER BY Total_Sales DESC;
SELECT Category, SUM(Profit) AS Total_Profit
FROM sales_data
GROUP BY Category
ORDER BY Total_Profit DESC;
SELECT MONTH(Order_Date) AS Month,
SUM(Sales) AS Total_Sales
FROM sales_data
GROUP BY MONTH(Order_Date)
ORDER BY Month;
SELECT Product_Name, SUM(Profit) AS Total_Loss
FROM sales_data
GROUP BY Product_Name
ORDER BY Total_Loss ASC
LIMIT 5;
SELECT Segment, SUM(Sales) AS Total_Sales
FROM sales_data
GROUP BY Segment
ORDER BY Total_Sales DESC;
SELECT Category, AVG(Sales) AS Average_Sales
FROM sales_data
GROUP BY Category
ORDER BY Average_Sales DESC;
SELECT State, SUM(Sales) AS Total_Sales
FROM sales_data
GROUP BY State
ORDER BY Total_Sales DESC;
SELECT Category, AVG(Discount) AS Average_Discount
FROM sales_data
GROUP BY Category
ORDER BY Average_Discount DESC;
SELECT Order_ID, Product_Name, Profit
FROM sales_data
WHERE Profit < 0
ORDER BY Profit ASC;
SELECT Order_ID, Product_Name, Profit
FROM sales_data
WHERE Profit < 0
ORDER BY Profit ASC;
SELECT Ship_Mode, COUNT(*) AS Total_Orders
FROM sales_data
GROUP BY Ship_Mode
ORDER BY Total_Orders DESC;
SELECT Market, SUM(Sales) AS Total_Revenue
FROM sales_data
GROUP BY Market
ORDER BY Total_Revenue DESC;
SELECT Sub_Category, SUM(Profit) AS Total_Profit
FROM sales_data
GROUP BY Sub_Category
ORDER BY Total_Profit DESC
LIMIT 10;